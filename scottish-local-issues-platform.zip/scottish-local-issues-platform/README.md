# Scottish Local Issues Platform

This version includes a full **React + Node.js + MySQL** project with:

- a public home page
- public issue browsing
- citizen-only public signup
- login for citizen, council, and admin users
- citizen issue reporting and voting after login
- council issue management
- admin user management panel for creating council/admin accounts without phpMyAdmin

## Main flow

- Visitors land on a **home page**.
- They can **see current issues without logging in**.
- They **cannot report or vote** unless they sign up or log in.
- Public signup creates **citizen** accounts only.
- **Council** and **admin** accounts are created internally.
- **Admins** can create council/admin users from the app itself.

## Tech stack

Frontend:
- React
- Vite
- TypeScript

Backend:
- Node.js
- Express
- MySQL
- JWT authentication
- bcrypt password hashing

## Project structure

- `src/` → frontend
- `backend/` → Express API
- `backend/sql/schema.sql` → database schema
- `backend/sql/seed.sql` → seed data

## Setup

### 1. Start MySQL in XAMPP
Start **MySQL** in XAMPP.

### 2. Import the database
In phpMyAdmin import these files in order:

1. `backend/sql/schema.sql`
2. `backend/sql/seed.sql`

### 3. Backend environment
Create `backend/.env` from `backend/.env.example`.

Use:

```env
PORT=5000
FRONTEND_URL=http://localhost:3000,http://localhost:5173
JWT_SECRET=change_this_to_a_long_random_secret
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=scottish_local_issues
```

### 4. Frontend environment
Create `.env` in the project root:

```env
VITE_API_BASE_URL=http://localhost:5000/api
```

### 5. Install and run backend

```bash
cd backend
npm install
npm run dev
```

### 6. Install and run frontend

```bash
cd ..
npm install
npm run dev
```

## Demo accounts

After importing `seed.sql`:

- Citizen: `citizen@example.com` / `password123`
- Council: `council@example.com` / `password123`
- Admin: `admin@council.com` / `password123`

## What admin can do

After logging in as admin:

- open the **Users** tab in the dashboard
- create new **council** accounts
- create new **admin** accounts
- stop using phpMyAdmin for staff creation

## API summary

### Auth
- `POST /api/auth/signup` → citizen only
- `POST /api/auth/login`
- `GET /api/auth/me`

### Issues
- `GET /api/issues` → public
- `POST /api/issues` → citizen only
- `POST /api/issues/:id/vote` → citizen only
- `PUT /api/issues/:id/status` → council or admin

### Admin
- `GET /api/admin/users` → admin only
- `POST /api/admin/users` → admin only

### Health
- `GET /api/health`

## Build check

This project has been updated so the frontend builds successfully with Vite and the backend files have valid Node.js syntax.
